package org.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CreateConnection {
    public static void main(String[] args) {
        try{
            Connection con = DBCPDataSource.getConnection();
            PreparedStatement p =null;
            ResultSet rs = null;
            try{
                String sql = "select * from studentbasicinformation";
                p= con.prepareStatement(sql);

                System.out.println("id\t\tname\t\temail");
                while(rs.next()){
                    String name = rs.getString("studentname");
                    System.out.println(name);
                }

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
