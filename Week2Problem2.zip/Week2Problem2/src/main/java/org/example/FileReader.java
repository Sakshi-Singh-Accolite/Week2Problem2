package org.example;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;
import java.net.URL;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Cell;

import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.Iterator;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.LinkedList;
import java.util.List;

public class FileReader {
    public static void main(String[] args) {
        try {
            //String excelUrl = ;
           // FileInputStream fis=new FileInputStream(new File("C:\\demo\\student.xls"));
            InputStream excelInputStream = new URL("https://docs.google.com/spreadsheets/d/1-E4EAizNV2ozKKMvD9ifTK83cpthKszd/edit#gid=190050555").openStream();
            XSSFWorkbook workbook = new XSSFWorkbook(excelInputStream);

            Sheet sheet = workbook.getSheetAt(0);
            List<MyData> dataList= new ArrayList<>();

            Iterator<Row> rowIterator = sheet.rowIterator();
            while (rowIterator.hasNext()){
                Row row = rowIterator.next();
                if(row.getRowNum()== 0){
                    continue;
                }
                MyData myData= new MyData();

                Iterator<Cell> cellIterator = row.cellIterator();
                while (cellIterator.hasNext()){
                    Cell cell = cellIterator.next();
                    int columnIndex = cell.getColumnIndex();

                    switch(columnIndex){
                        case 0:
                            myData.setName(cell.getStringCellValue());
                            break;
                        //case 1:
                    }
                }
                dataList.add(myData);
            }

//            BufferedWriter writer= new BufferedWriter(new FileWriter("C:\\Users\\sakshi.singh\\IdeaProjects\\Week2Problem2\\src\\main\\resources\\ReadFile.txt"));
//            for(String item:str){
//                writer.write(item);
//                writer.newLine();
//            }

        workbook.close();
        excelInputStream.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
