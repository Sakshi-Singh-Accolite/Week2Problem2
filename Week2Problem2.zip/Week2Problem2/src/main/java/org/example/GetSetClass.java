package org.example;

public class GetSetClass {

}
