package tasks;

public class Solve {
}
